<!-- NavBar search -->
<form role="search" method="get" id="searchform" class="form-search pull-right" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <input type="text" class="input-medium" name="s" value="<?php echo get_search_query(); ?>">
    <button type="submit" class="btn">
		<span class="sosa">
			]
		</span>
	</button>
</form>