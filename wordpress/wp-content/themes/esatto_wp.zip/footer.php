<?php 
/**
 * Footer
 */
?>
<?php spyropress_wrapper_end(); ?>
<?php spyropress_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>