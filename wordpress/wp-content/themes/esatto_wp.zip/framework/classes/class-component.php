<?php

/**
 * FAQ Component
 */

class SpyropressComponent {
    
}
?>