<div class="section section-subheading">
	<h3 class="heading">
		Contact us
	</h3>
	<div class="description">
		Need any help! contact us using any method given below.
	</div>
	<div class="clear">
	</div>
</div>
<div class="section" style="font-size: 14px;">
	<h3 class="heading">
		Support Forum
	</h3>
	<p>
		We set up a support forum at
		<a target="_blank" href="http://spyropress.com/forums">spyropress.com/forums</a>
		, processing all requests at one place keeps and makes it simple, easier and even more effective for every customers to get quick help.
	</p>
	<p>
		All issues, requests and questions can be discussed and solved at one place. You only have to choose your related theme forum.
	</p>
	<p>
		<strong>
			Note:
		</strong>
	</p>
	<ul>
		<li>
			1. You will only get access to our forums with a valid purchase key!
		</li>
		<li>
			2. We cannot make any changes without compensation.
		</li>
	</ul>
</div>
<div class="section" style="font-size: 14px;">
	<h3 class="heading">
		Email Us or Call
	</h3>
	<p>
		If you need some extra care, please do not shy to contact us!
	</p>
	<ul>
		<li>
			<strong>
				Email:
			</strong>
			info@spyropress.com
		</li>
		<li>
			<strong>
				Skype:
			</strong>
			spyropress
		</li>
	</ul>
</div>